const APP_TITLE = 'Laravel React Boiler Plate'

export {
    APP_TITLE,
}
